<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Products - TearDrop Toys</title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;700&family=Baloo+2:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        /* General Page Styling */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #E3FDFD, #FFE6FA);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 80px; /* Ensures content doesn't hide under navbar */
        }

        /* Navbar Styling */
        .navbar {
            width: 100%;
            background-color: #0e2954;
            padding: 10px 40px;
            height: 60px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-sizing: border-box;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            font-family: "Fredoka", sans-serif;
            flex-grow: 1;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px; /* Ensures proper spacing */
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-family: "Baloo 2", sans-serif;
            padding: 10px;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }

        /* Page Header */
        .welcome-message {
            font-size: 28px;
            color: #002B5B;
            text-align: center;
            margin-bottom: 20px;
        }

        h2 {
            color: #002B5B;
            font-size: 32px;
            margin-bottom: 20px;
        }

        /* Product Grid */
        .container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            width: 90%;
            max-width: 1200px;
        }

        /* Product Card */
        .product-box {
            background: white;
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .product-box:hover {
            transform: translateY(-8px);
            box-shadow: 0 16px 24px rgba(0, 0, 0, 0.15);
        }

        img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 16px;
        }

        .product-name {
            font-size: 20px;
            font-weight: bold;
            margin: 12px 0;
            color: #002B5B;
        }

        .product-price {
            font-size: 18px;
            color: #007bff;
            font-weight: bold;
        }

        .product-stock {
            font-size: 16px;
            color: #28a745;
            font-weight: bold;
            margin: 8px 0;
        }

        .product-description {
            font-size: 14px;
            color: #555;
            margin: 10px 0;
        }

        /* Buy Button */
        .buy-button {
            display: inline-block;
            padding: 12px 20px;
            background-color: #FF6B6B;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }

        .buy-button:hover {
            background-color: #E63946;
        }

        .out-of-stock {
            color: #FF0000;
            font-weight: bold;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <span class="logo">TearDrop Toys</span>
    <div class="nav-links">
        <a href="product.php">Home</a>
        <a href="search.php">Search</a>
        <a href="logout.php">Log out</a>
<?php session_start(); ?> <!-- Ensure session is started -->
<div class="navbar">
    <span class="logo">TearDrop Toys</span>
    <div class="nav-links">
        <a href="product.php">Home</a>
        <a href="search.php">Search</a>
        <a href="logout.php">Log out</a>
        <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
            <a href="admin.php">Dashboard</a>
        <?php endif; ?>
    </div>
</div>

    </div>
</div>

<!-- Welcome Message -->
<div class="welcome-message">Welcome, Guest!</div>

<!-- Page Title -->
<h2>Available Products</h2>

<!-- PHP: Fetch Products -->
<?php
include("connections.php");

// Create products table if it doesn't exist
$create_table_query = "CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description TEXT NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    stock INT DEFAULT 0
)";
mysqli_query($connections, $create_table_query);

// Fetch products
$products_query = mysqli_query($connections, "SELECT * FROM products");
?>

<!-- Products List -->
<div class="container">
    <?php while ($product = mysqli_fetch_assoc($products_query)) : ?>
        <div class="product-box">
            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
            <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
            <div class="product-price">₱<?php echo number_format($product['price'], 2); ?></div>
            <div class="product-stock">
                <?php if ($product['stock'] > 0): ?>
                    Stock: <?php echo $product['stock']; ?>
                <?php else: ?>
                    <span class="out-of-stock">Out of Stock</span>
                <?php endif; ?>
            </div>
            <div class="product-description"><?php echo htmlspecialchars($product['description']); ?></div>
            <form action="buy.php" method="POST">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <button type="submit" class="buy-button" <?php echo ($product['stock'] > 0) ? '' : 'disabled'; ?>>Buy Now</button>
            </form>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
