<?php
session_start();
include("connections.php");

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit();
}

// Remove unnecessary redirection
// header("Location: admin.php"); 
// exit();

// Handle search
$search = "";
$user_results = [];
$product_results = [];

// Fetch all users and products initially
$user_query = mysqli_query($connections, "SELECT * FROM mytbl") or die(mysqli_error($connections));
while ($user = mysqli_fetch_assoc($user_query)) {
    $user_results[] = $user;
}

$product_query = mysqli_query($connections, "SELECT * FROM products") or die(mysqli_error($connections));
while ($product = mysqli_fetch_assoc($product_query)) {
    $product_results[] = $product;
}

// Perform search if applicable
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["search"])) {
    $search = mysqli_real_escape_string($connections, $_POST["search"]);
    
    // Search for users
    $user_query = mysqli_query($connections, "SELECT * FROM mytbl WHERE name LIKE '%$search%' OR email LIKE '%$search%'") or die(mysqli_error($connections));
    $user_results = [];
    while ($user = mysqli_fetch_assoc($user_query)) {
        $user_results[] = $user;
    }

    // Search for products
    $product_query = mysqli_query($connections, "SELECT * FROM products WHERE name LIKE '%$search%' OR description LIKE '%$search%'") or die(mysqli_error($connections));
    $product_results = [];
    while ($product = mysqli_fetch_assoc($product_query)) {
        $product_results[] = $product;
    }
}
?>


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TearDrop Toys</title>
    
    <!-- Move the font link here -->
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Fredoka', sans-serif; /* Now it will apply correctly */
        }
        .navbar {
            width: 100%;
            background-color: #0e2954;
            padding: 8px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-sizing: border-box;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .navbar .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .nav-links a { 
            color: white; 
            text-decoration: none; 
            margin-left: 30px; 
            font-size: 16px; 
        }

        .nav-links a:hover { 
            text-decoration: underline; 
        }

        .form-container {
            background: white; 
            padding: 20px; 
            border-radius: 10px; 
            width: 50%; 
            margin: 50px auto; 
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        input, button {
            margin: 10px 0; 
            padding: 10px; 
            width: 90%; 
            font-size: 16px;
        }

        button {
            background: #28a745; 
            color: white; 
            border: none; 
            cursor: pointer; 
            border-radius: 5px;
        }

        button:hover { 
            background: #218838; 
        }

        table { 
            width: 90%; 
            margin: 20px auto; 
            border-collapse: collapse; 
            background: white; 
        }

        th, td { 
            border: 1px solid #ddd; 
            padding: 12px; 
            text-align: left; 
        }

        th { 
            background: #0e2954; 
            color: white; 
        }

        a { 
            text-decoration: none; 
            color: red; 
        }

        a:hover { 
            text-decoration: underline; 
        }
		h2,h4{
			text-align: center;
			margin-top: 20px; /* Adjust spacing */
			font-size: 20px; /* Optional: Make it more readable */
		}

    </style>
</head>
<body>

<div class="navbar">
  <span class="logo">TearDrop Toys - Admin</span>
	<div class="nav-links">
		<a href="admin.php">Search</a>
		<a href="admin.php">Home</a>
		<a href="logout.php">Logout</a>
	</div>

</div>

<h2>Search</h2>
<div class="form-container">
    <form method="POST">
        <input type="text" name="search" placeholder="Enter search keyword..." value="<?php echo htmlspecialchars($search); ?>" required>
        <button type="submit">Search</button>
    </form>
</div>

<h4>Users</h4>
<table>
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($user_results as $user): ?>
        <tr>
            <td><?php echo htmlspecialchars($user["name"]); ?></td>
            <td><?php echo htmlspecialchars($user["email"]); ?></td>
            <td>
                <a href="Edit.php?id=<?php echo intval($user['id']); ?>">Edit</a> |
                <a href="delete_user.php?id=<?php echo intval($user['id']); ?>" onclick="return confirm('Are you sure?');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<h4>Products</h4>
<table>
    <tr>
        <th>Name</th>
        <th>Price</th>
        <th>Description</th>
        <th>Stock</th>
        <th>Image</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($product_results as $product): ?>
        <tr>
            <td><?php echo htmlspecialchars($product["name"]); ?></td>
            <td>₱<?php echo number_format($product["price"], 2); ?></td>
            <td><?php echo htmlspecialchars($product["description"]); ?></td>
            <td>
				<?php
				if (isset($product["stock"])) {
					echo intval($product["stock"]);
				} else {
					echo "N/A";
				}
				?>
			</td>

            <td><img src="<?php echo htmlspecialchars($product["image_url"]); ?>" width="50" height="50"></td>
            <td>
                <form method="POST" action="update_stock.php" style="display:inline;">
					<input type="hidden" name="product_id" value="<?php echo intval($product['id']); ?>">
					<input type="number" name="stock_change" value="0" style="width: 60px;">
					<button type="submit" name="adjust_stock">Adjust</button>
				</form>

                <a href="edit_product.php?id=<?php echo intval($product['id']); ?>">Edit</a> |
                <a href="delete_product.php?id=<?php echo intval($product['id']); ?>" onclick="return confirm('Are you sure?');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
