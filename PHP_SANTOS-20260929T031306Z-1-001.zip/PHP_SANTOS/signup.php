<?php
include("connections.php");

$name = $address = $email = $password = $cpassword = "";
$nameErr = $addressErr = $emailErr = $passwordErr = $cpasswordErr = "";

if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if(empty($_POST["name"])){
        $nameErr = "Name is required!";
    }else{
        $name = $_POST["name"];
    }
    if(empty($_POST["address"])){
        $addressErr = "Address is required!";
    }else{
        $address = $_POST["address"];
    }
    if(empty($_POST["email"])){
        $emailErr = "Email is required!";
    }else{
        $email = $_POST["email"];
    }
    if(empty($_POST["password"])){
        $passwordErr = "Password is required!";
    }else{
        $password = $_POST["password"];
    }
    if(empty($_POST["cpassword"])){
        $cpasswordErr = "Confirm Password is required!";
    }else{
        $cpassword = $_POST["cpassword"];
    }
    
    
    if($name && $address && $email && $password && $cpassword) {
        $check_email = mysqli_query($connections, "SELECT * FROM mytbl WHERE email='$email'");
        $check_email_row = mysqli_num_rows($check_email);

        if($check_email_row > 0) {
            $emailErr = "Email is already registered!";
        } else {
            $query = mysqli_query($connections, "INSERT INTO mytbl(name, address, email, password, account_type) VALUES('$name', '$address', '$email', '$cpassword', '2')");
            echo "<script language='javascript'>alert('New record has been inserted!')</script>";
            echo "<script>window.location.href='index.php';</script>";
        }
    }   
}
?>

<style>
body {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100vh;
  background-color: #f0f2f5;
  font-family: Arial, sans-serif;
  margin: 0;
}

.navbar {
    width: 100%;
    background-color: #0e2954;
    padding: 10px 40px; /* Increased side padding */
    height: 60px; /* Slightly increased height */
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
    position: fixed; /* Ensures it stays at the top */
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
}

.navbar .logo {
    font-size: 24px;
    font-weight: bold;
    color: white;
    font-family: "Fredoka", sans-serif;
    flex-grow: 1;
}

.nav-links {
    display: flex;
    gap: 20px; /* Adds spacing between links */
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    font-family: "Baloo 2", sans-serif;
    padding: 10px 15px;
}

.nav-links a:hover {
    text-decoration: underline;
}

/* Ensure visited and active links stay white */
.navbar a:visited, .navbar a:active {
  color: white;
}

/* Form container */
.form-container {
  width: 400px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.2);
  padding: 20px;
  text-align: center;
  margin-top: 50px;
}

/* Titles */
.title {
  font-size: 24px;
  font-weight: bold;
  color: #0e2954;
}

.form-sub-title {
  font-size: 14px;
  color: #6c757d;
  margin-bottom: 20px;
}

/* Input fields */
.input {
  width: 90%;
  padding: 12px;
  margin: 10px 0;
  border-radius: 5px;
  border: 1px solid #ccc;
  font-size: 16px;
  text-align: left;
}

.input::placeholder {
  color: #aaa;
}

/* Buttons */
.btn {
  background: #0e2954;
  color: white;
  padding: 12px;
  width: 100%;
  border: none;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  margin-top: 10px;
}

.btn:hover {
  background: #092040;
}

/* Error messages */
.error {
  color: red;
  font-size: 12px;
}

/* Background styling */
body {
  background-image: url('bg4.jpg'); /* Image file in the same folder */
  background-size: cover; /* Cover full screen */
  background-position: center; /* Center the image */
  background-repeat: no-repeat; /* No repeating */
  height: 100vh; /* Full height */
  margin: 0;
}


</style>

<!-- Navigation Bar -->
<div class="navbar">
  <span class="logo">TearDrop Toys</span>
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;700&display=swap" rel="stylesheet">


  <div class="nav-links">
	<a href="index.php">Home</a>
    <a href="index.php">Login</a>
  </div>
</div>

<!-- Registration Form -->
<form class="form-container" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
	<p class="title">Create an account</p>
	<p class="form-sub-title">Shop with us today by filling out the form below.</p>
  
  <label>
    <input required name="name" type="text" class="input" value="<?php echo $name; ?>" placeholder="Name" />
  </label>
  <span class="error"> <?php echo $nameErr; ?> </span>

  <label>
    <input required name="address" type="text" class="input" value="<?php echo $address; ?>" placeholder="Address" />
  </label>
  <span class="error"> <?php echo $addressErr; ?> </span>
  
  <label>
    <input required name="email" type="email" class="input" value="<?php echo $email; ?>" placeholder="Email" />
  </label>
  <span class="error"> <?php echo $emailErr; ?> </span>
  
  <label>
    <input required name="password" type="password" class="input" placeholder="Password" />
  </label>
  <span class="error"> <?php echo $passwordErr; ?> </span>
  
  <label>
    <input required name="cpassword" type="password" class="input" placeholder="Confirm Password" />
  </label>
  <span class="error"> <?php echo $cpasswordErr; ?> </span>
  
  <button class="btn">Continue</button>
  <p class="signin">Already have an account? <a href="index.php">Log in</a></p>
</form>