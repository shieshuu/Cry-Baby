<?php
session_start();
include("connections.php");

// Function to check if 'stock' column exists
function columnExists($connections, $table, $column) {
    $query = "SHOW COLUMNS FROM $table LIKE '$column'";
    $result = $connections->query($query);
    return $result->num_rows > 0;
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['adjust_stock'])) {
    $product_id = intval($_POST['product_id']);
    $stock_change = intval($_POST['stock_change']);

    // Check if 'stock' column exists
    if (!columnExists($connections, 'products', 'stock')) {
        echo "Error: 'stock' column does not exist in the 'products' table.";
        exit();
    }

    // Update the product stock in the database
    $query = "UPDATE products SET stock = stock + ? WHERE id = ?";
    $stmt = $connections->prepare($query);

    if ($stmt) {
        $stmt->bind_param("ii", $stock_change, $product_id);
        if ($stmt->execute()) {
            // Redirect back to the admin page or display a success message
            header("Location: admin.php");
            exit();
        } else {
            echo "Error updating stock: " . $stmt->error;
        }
    } else {
        echo "Error in SQL statement: " . $connections->error;
    }
}
?>
