<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Purchase Confirmation - TearDrop Toys</title>
<style>
body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(135deg, #E3FDFD, #FFE6FA);
  font-family: Arial, sans-serif;
  margin: 0;
}

.container {
  width: 400px;
  background-color: white;
  padding: 40px;
  border-radius: 20px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
  text-align: center;
}

h2 {
  color: #002B5B;
}

p {
  color: #6c757d;
  margin: 10px 0;
}

img {
  width: 200px;
  height: auto;
  border-radius: 10px;
}

a {
  display: inline-block;
  margin-top: 20px;
  text-decoration: none;
  color: #fff;
  font-weight: bold;
  background-color: #E63946;
  padding: 10px 20px;
  border-radius: 10px;
  transition: background-color 0.3s;
}

a:hover {
  background-color: #d62839;
}
</style>
</head>
<body>
<div class="container">
  <?php
  session_start();
  include("connections.php");

  if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
      header("Location: index.php");
      exit();
  }

  if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['product_id'])) {
      $product_id = intval($_POST['product_id']);

      // Get the product details
      $query = mysqli_query($connections, "SELECT * FROM products WHERE id = $product_id");
      $product = mysqli_fetch_assoc($query);

      if ($product) {
          if ($product['stock'] > 0) {
              // Decrease stock by 1
              $new_stock = $product['stock'] - 1;
              mysqli_query($connections, "UPDATE products SET stock = $new_stock WHERE id = $product_id");

              echo "<h2>Thank you for your purchase!</h2>";
              echo "<p>You have bought: <strong>" . htmlspecialchars($product['name']) . "</strong></p>";
              echo "<p>Price: $" . number_format($product['price'], 2) . "</p>";
              echo "<img src='" . htmlspecialchars($product['image_url']) . "' alt='" . htmlspecialchars($product['name']) . "'>";
          } else {
              echo "<h2>Sorry, this product is out of stock!</h2>";
          }
      } else {
          echo "<h2>Product not found!</h2>";
      }
      echo "<br><a href='user.php'>Back to Products</a>";
  } else {
      echo "<h2>Invalid Request!</h2>";
      echo "<a href='user.php'>Back to Products</a>";
  }
  ?>
</div>
</body>
</html>
