<?php
session_start();
include("connections.php");

// Check if an admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit();
}

// Check if 'id' is provided
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $user_id = intval($_GET['id']); // Convert to an integer for security

    // Execute delete query
    $delete_query = "DELETE FROM mytbl WHERE id = $user_id";
    if (mysqli_query($connections, $delete_query)) {
        // Redirect back to admin dashboard
        header("Location: admin.php?message=UserDeleted");
        exit();
    } else {
        echo "Error deleting user: " . mysqli_error($connections);
    }
} else {
    echo "Invalid request.";
}
?>
