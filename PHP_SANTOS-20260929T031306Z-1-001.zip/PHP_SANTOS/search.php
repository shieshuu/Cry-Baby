<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Products - TearDrop Toys</title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;700&family=Baloo+2:wght@400;700&display=swap" rel="stylesheet">

    <style>
        /* General Page Styling */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #E3FDFD, #FFE6FA);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 80px; /* Ensures content is visible under navbar */
        }

        /* Navbar Styling */
        .navbar {
            width: 100%;
            background-color: #0e2954;
            padding: 10px 40px;
            height: 60px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-sizing: border-box;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            font-family: "Fredoka", sans-serif;
            flex-grow: 1;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-family: "Baloo 2", sans-serif;
            padding: 10px;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }

        /* Page Header */
        .welcome-message {
            font-size: 28px;
            color: #002B5B;
            text-align: center;
            margin-bottom: 20px;
        }

        h2 {
            color: #002B5B;
            font-size: 32px;
            margin-bottom: 20px;
        }

        /* Search Bar */
        .search-container {
            margin-bottom: 20px;
            text-align: center;
        }

        .search-box {
            padding: 10px;
            width: 300px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        .search-button {
            padding: 10px 15px;
            font-size: 16px;
            background-color: #FF6B6B;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .search-button:hover {
            background-color: #E63946;
        }

        /* Product Grid */
        .container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            width: 90%;
            max-width: 1200px;
        }

        /* Product Card */
        .product-box {
            background: white;
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .product-box:hover {
            transform: translateY(-8px);
            box-shadow: 0 16px 24px rgba(0, 0, 0, 0.15);
        }

        img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 16px;
        }

        .product-name {
            font-size: 20px;
            font-weight: bold;
            margin: 12px 0;
            color: #002B5B;
        }

        .product-price {
            font-size: 18px;
            color: #007bff;
            font-weight: bold;
        }

        .product-description {
            font-size: 14px;
            color: #555;
            margin: 10px 0;
        }

        /* Buy Button */
        .buy-button {
            display: inline-block;
            padding: 12px 20px;
            background-color: #FF6B6B;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }

        .buy-button:hover {
            background-color: #E63946;
        }

        .no-results {
            font-size: 18px;
            color: #555;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <span class="logo">TearDrop Toys</span>
    <div class="nav-links">
        <a href="product.php">Home</a>
        <a href="search.php">Search</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<!-- Welcome Message -->
<div class="welcome-message">Search for Products</div>

<!-- Page Title -->
<h2>Find Your Favorite Toys</h2>

<!-- Search Bar -->
<div class="search-container">
    <form method="GET">
        <input type="text" name="search" class="search-box" placeholder="Enter product name..." required>
        <button type="submit" class="search-button">Search</button>
    </form>
</div>

<!-- PHP: Fetch Products -->
<div class="container">
    <?php
    include("connections.php");

    if (isset($_GET['search'])) {
        $search_term = mysqli_real_escape_string($connections, $_GET['search']);

        // Fetch matching products
        $products_query = mysqli_query($connections, "SELECT * FROM products WHERE name LIKE '%$search_term%'");

        if (mysqli_num_rows($products_query) > 0) {
            while ($product = mysqli_fetch_assoc($products_query)) : ?>
                <div class="product-box">
                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                    <div class="product-price">$<?php echo number_format($product['price'], 2); ?></div>
                    <div class="product-description"><?php echo htmlspecialchars($product['description']); ?></div>
                    <form action="buy.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        <button type="submit" class="buy-button">Buy Now</button>
                    </form>
                </div>
            <?php endwhile;
        } else {
            echo "<div class='no-results'>No products found. Try searching for something else.</div>";
        }
    }
    ?>
</div>

</body>
</html>
