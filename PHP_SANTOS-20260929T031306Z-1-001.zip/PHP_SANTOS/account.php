<?php
session_start();
include("connections.php");

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Use prepared statements to prevent SQL injection
$stmt = $connections->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("User not found.");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - TearDrop Toys</title>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;700&family=Baloo+2:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #E3FDFD, #FFE6FA);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 80px;
        }

        .navbar {
            width: 100%;
            background-color: #0e2954;
            padding: 10px 40px;
            height: 60px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            font-family: "Fredoka", sans-serif;
            flex-grow: 1;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-family: "Baloo 2", sans-serif;
            padding: 10px;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }

        .account-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 80%;
            max-width: 400px;
            margin-top: 20px;
        }

        h2 {
            color: #002B5B;
        }

        p {
            font-size: 16px;
            color: #555;
            margin: 10px 0;
        }

        .logout-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #FF6B6B;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
            text-decoration: none;
        }

        .logout-button:hover {
            background-color: #E63946;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <span class="logo">TearDrop Toys</span>
    <div class="nav-links">
        <a href="product.php">Home</a>
        <a href="search.php">Search</a>
        <a href="account.php">Account</a>
        <a href="logout.php" class="logout-button">Log out</a>
    </div>
</div>

<!-- Account Details -->
<div class="account-container">
    <h2>My Account</h2>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
    <p><strong>Joined:</strong> <?php echo htmlspecialchars($user['created_at']); ?></p>
</div>

</body>
</html>
