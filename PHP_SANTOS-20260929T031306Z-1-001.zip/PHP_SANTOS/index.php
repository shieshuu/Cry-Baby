<?php
session_start(); // Start session for tracking login state

$email = $password = "";
$emailErr = $passwordErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include("connections.php");

    if (empty($_POST["email"])) {
        $emailErr = "Email is required!";
    } else {
        $email = mysqli_real_escape_string($connections, $_POST["email"]);
    }

    if (empty($_POST["password"])) {
        $passwordErr = "Password is required!";
    } else {
        $password = $_POST["password"];
    }

    if ($email && $password) {
        $check_email = mysqli_query($connections, "SELECT * FROM mytbl WHERE email='$email'");
        $check_email_row = mysqli_num_rows($check_email);

        if ($check_email_row > 0) {
            $row = mysqli_fetch_assoc($check_email);
            $db_password = $row["password"];
            $db_account_type = $row["account_type"];

            if ($password == $db_password) {
                $_SESSION['email'] = $email;
                $_SESSION['account_type'] = $db_account_type;

                if ($db_account_type == "1") {
                    $_SESSION['admin_logged_in'] = true;
                    header("Location: admin.php");
                    exit();
                } else {
                    $_SESSION['user_logged_in'] = true;
                    header("Location: user.php");
                    exit();
                }
            } else {
                $passwordErr = "Password is incorrect!";
            }
        } else {
            $emailErr = "Email is not registered!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - TearDrop Toys</title>
<style>
body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(135deg, #E3FDFD, #FFE6FA);
  font-family: Arial, sans-serif;
  margin: 0;
}

.navbar {
    width: 100%;
    background-color: #0e2954;
    padding: 10px 40px; /* Increased side padding */
    height: 60px; /* Slightly increased height */
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
    position: fixed; /* Ensures it stays at the top */
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
}

.navbar .logo {
    font-size: 24px;
    font-weight: bold;
    color: white;
    font-family: "Fredoka", sans-serif;
    flex-grow: 1;
}

.nav-links {
    display: flex;
    gap: 20px; /* Adds spacing between links */
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    font-family: "Baloo 2", sans-serif;
    padding: 10px 15px;
}

.nav-links a:hover {
    text-decoration: underline;
}


.container {
  width: 400px;
  background-color: white;
  padding: 40px;
  border-radius: 20px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
  text-align: center;
}

h1 {
  color: #002B5B;
  margin-bottom: 10px;
}

p {
  color: #6c757d;
  margin-bottom: 20px;
}

.input {
  width: 90%;
  padding: 12px;
  margin: 10px 0;
  border-radius: 10px;
  border: 1px solid #ccc;
  font-size: 16px;
}

.btn {
  background-color: #0e2954;
  color: white;
  padding: 12px;
  width: 100%;
  border: none;
  border-radius: 10px;
  font-size: 16px;
  cursor: pointer;
  margin-top: 10px;
}

.btn:hover {
  background-color: #E63946;
}

.error {
  color: red;
  font-size: 12px;
}
/* Background styling */
body {
  background-image: url('bg4.jpg'); /* Image file in the same folder */
  background-size: cover; /* Cover full screen */
  background-position: center; /* Center the image */
  background-repeat: no-repeat; /* No repeating */
  height: 100vh; /* Full height */
  margin: 0;
}

</style>
</head>
<div class="navbar">
  <span class="logo">TearDrop Toys</span>
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;700&display=swap" rel="stylesheet">


  <div class="nav-links">
    <a href="signup.php">Sign up</a>
  </div>
</div>
<body>

<div class="container">
  <h1>Welcome Back!</h1>
  <p>Login to your TearDrop Toys account</p>
  <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <input class="input" type="text" name="email" placeholder="Email" value="<?php echo htmlspecialchars($email); ?>">
    <span class="error"><?php echo $emailErr; ?></span><br>

    <input class="input" type="password" name="password" placeholder="Password">
    <span class="error"><?php echo $passwordErr; ?></span><br>

    <input class="btn" type="submit" value="Login">
	<p class="signin">Already have an account? <a href="signup.php">Sign in</a></p
  </form>
</div>

</body>
</html>