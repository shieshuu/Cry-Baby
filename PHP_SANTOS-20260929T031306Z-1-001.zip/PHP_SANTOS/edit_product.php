<?php
session_start();
include("connections.php");

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit();
}

// Get product ID from URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid Product ID.");
}
$product_id = intval($_GET['id']);

// Fetch product details
$product_query = mysqli_query($connections, "SELECT * FROM products WHERE id = $product_id") or die(mysqli_error($connections));
$product = mysqli_fetch_assoc($product_query);
if (!$product) {
    die("Product not found.");
}

// Handle product update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($connections, $_POST["name"]);
    $price = mysqli_real_escape_string($connections, $_POST["price"]);
    $description = mysqli_real_escape_string($connections, $_POST["description"]);
    $image_url = mysqli_real_escape_string($connections, $_POST["image_url"]);

    $update_query = "UPDATE products SET name='$name', price='$price', description='$description', image_url='$image_url' WHERE id=$product_id";
    mysqli_query($connections, $update_query) or die(mysqli_error($connections));

    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Product</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; }
        .form-container { background: white; padding: 20px; border-radius: 10px; width: 50%; margin: 50px auto; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); }
        input, textarea, button { margin: 10px 0; padding: 10px; width: 90%; }
        textarea { height: 80px; resize: none; }
        button { background: #28a745; color: white; border: none; cursor: pointer; font-size: 16px; border-radius: 5px; }
        button:hover { background: #218838; }
    </style>
</head>
<body>

    <h2>Edit Product</h2>
    <div class="form-container">
        <form method="POST">
            <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
            <input type="number" step="0.01" name="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>
            <textarea name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea>
            <input type="text" name="image_url" value="<?php echo htmlspecialchars($product['image_url']); ?>" required>
            <button type="submit">Update Product</button>
        </form>
    </div>

    <a href="admin.php">Back to Admin Panel</a>

</body>
</html>
