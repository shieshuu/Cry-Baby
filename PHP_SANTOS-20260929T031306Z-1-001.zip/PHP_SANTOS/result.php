<?php
session_start();
include("connections.php");

// Restrict access to admins only
if (!isset($_SESSION['account_type']) || $_SESSION['account_type'] != "1") {
    echo "Access denied. You must be an admin to view this page.";
    exit();
}

if (empty($_GET["search"])) {
    echo "Walang laman si GET ...";
} else {
    $check = $_GET["search"];
    $terms = explode(" ", $check);
    $q = "SELECT * FROM mytbl WHERE ";
    $i = 0;

    foreach ($terms as $each) {
        $i++;
        if ($i == 1) {
            $q .= "name LIKE '%$each%'";
        } else {
            $q .= "OR name LIKE '%$each%'";
        }
    }

    $query = mysqli_query($connections, $q);
    $c_q = mysqli_num_rows($query);

    if ($c_q > 0 && $check != "") {
        while ($row = mysqli_fetch_assoc($query)) {
            echo $row["name"] . "<br>";
        }
    } else {
        echo "No result.";
    }
}
?>
