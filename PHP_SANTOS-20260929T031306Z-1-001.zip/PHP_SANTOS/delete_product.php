<?php
session_start();
include("connections.php");

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit();
}

// Check if product ID is set
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure ID is an integer

    // Delete the product
    $delete_query = mysqli_query($connections, "DELETE FROM products WHERE id = $id") or die(mysqli_error($connections));
}

// Redirect back to admin page
header("Location: admin.php");
exit();
?>
