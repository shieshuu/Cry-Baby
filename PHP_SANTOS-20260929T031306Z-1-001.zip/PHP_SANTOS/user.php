<?php
session_start();
include("connections.php");

// Check if the user is logged in
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: index.php");
    exit();
}

// Ensure 'name' is set in the session to avoid errors
$name = isset($_SESSION['name']) ? $_SESSION['name'] : "Guest";

// Include the product page (Check if the file exists)
if (file_exists("product.php")) {
    include("product.php");
} else {
    echo "<p style='color:red;'>Error: Product page not found!</p>";
}

?>
	